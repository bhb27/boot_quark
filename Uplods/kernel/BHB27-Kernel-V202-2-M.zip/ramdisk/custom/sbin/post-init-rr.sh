#!/system/bin/sh

mount -o rw,remount /system

# only present on RR this need to be 755 to execute...
if [ -e /system/app/Adaway/lib/arm/libblank_webserver_exec.so ]; then
	
	chmod 755 /system/app/Adaway/lib/arm/libblank_webserver_exec.so

fi

if [ -e /system/app/Adaway/lib/arm/libtcpdump_exec.so ]; then
	
	chmod 755 /system/app/Adaway/lib/arm/libtcpdump_exec.so

fi

fsgid=`getprop ro.boot.fsg-id`;
device=`getprop ro.boot.hardware.sku`

if  [ "$device" == XT1225 ] ||  [ "$fsgid" == emea ] || [ "$fsgid" == singlela ]; then
	# stop IMS services Not need for others then VZW users
	stop imsqmidaemon;
	stop imsdatadaemon;
	setprop net.lte.volte_call_capable false
	echo "services stop okay $(date) device = $device fsgid = $fsgid" >> /data/tmp/bootcheck.txt;

else
	echo "services not stoped $(date) for device = $device fsgid = $fsgid" >> /data/tmp/bootcheck.txt;
fi;

echo "post-init-ROM Boot initiated on $(date)" >> /data/tmp/bootcheck.txt
umount /system;
exit

